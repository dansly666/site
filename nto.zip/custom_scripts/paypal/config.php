<?php
$paypal_report_url = 'http://nto-hard.com/paypal_report.php';
$paypal_return_url = 'http://nto-hard.com/?subtopic=shopsystem';
$paypal_image = 'https://www.paypal.com/en_US/i/btn/btn_donate_LG.gif';
$paypal_payment_type = '_xclick'; // '_xclick' (Buy Now) or '_donations'

$paypals[0]['mail'] = 'roberto-games78@hotmail.com'; // your paypal login
$paypals[0]['name'] = 'NTOHard Points';
$paypals[0]['money_amount'] = '50.00';
$paypals[0]['money_currency'] = 'BRL'; // USD, EUR, more codes: https://cms.paypal.com/us/cgi-bin/?cmd=_render-content&content_ID=developer/e_howto_api_nvp_currency_codes
$paypals[0]['premium_points'] = 75;

$paypals[1]['mail'] = 'roberto-games78@hotmail.com'; // your paypal login
$paypals[1]['name'] = 'NTOHard Points';
$paypals[1]['money_amount'] = '100.00';
$paypals[1]['money_currency'] = 'BRL'; // USD, EUR, more codes: https://cms.paypal.com/us/cgi-bin/?cmd=_render-content&content_ID=developer/e_howto_api_nvp_currency_codes
$paypals[1]['premium_points'] = 175;

$paypals[2]['mail'] = 'roberto-games78@hotmail.com'; // your paypal login
$paypals[2]['name'] = 'NTOHard Points';
$paypals[2]['money_amount'] = '150.00';
$paypals[2]['money_currency'] = 'BRL'; // USD, EUR, more codes: https://cms.paypal.com/us/cgi-bin/?cmd=_render-content&content_ID=developer/e_howto_api_nvp_currency_codes
$paypals[2]['premium_points'] = 300;
<p style="text-align: center;">&nbsp;</p>
<p><a href="https://imgbb.com/"><img style="display: block; margin-left: auto; margin-right: auto;" src="https://i.ibb.co/cD6d7FR/logo-back.png" alt="logo-back" width="274" height="170" border="0" /></a></p>
<table style="width: 600px; margin-left: auto; margin-right: auto; height: 24px; border-color: #0a0a0a; border-width: 0px; border-style: solid; background-color: #0a0a0a;" border="0" cellspacing="1" cellpadding="0">
<tbody>
<tr>
<td style="text-align: left;" colspan="5" bgcolor="#505050"><span style="font-size: small;"><strong><span style="color: #505050;">..</span><span style="color: white;"><span style="font-size: small;">Downloads</span>:</span></strong></span></td>
</tr>
</tbody>
</table>
<table style="height: 80px; width: 601px; border-color: #050505; border-width: 2px; background-color: #65929a; border-style: solid;" border="2" align="center">
<tbody>
<tr>
<td style="text-align: center;"><strong><span style="color: #ffffff;">Client NTO Hard v 1.7 Zipado</span></strong></td>
<td style="text-align: center;"><a title="Client" href="http://nto-hard.com/client/NTOHard1_7.zip" target="_blank"><strong>DIRETO</strong></a></td>
</tr>
<tr>
<td style="text-align: center;"><strong><span style="color: #ffffff;">&nbsp; &nbsp;Elfbot 8.60 : NTO Hard Full Cracked</span></strong></td>
<td style="text-align: center;"><a title="Elfbot" href="http://bit.ly/2mzJxaE" target="_blank"><strong>DOWNLOAD</strong></a></td>
</tr>
</tbody>
</table>
<p>&nbsp;</p>
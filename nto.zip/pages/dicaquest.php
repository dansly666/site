<div class="contentCozy-3XX413 content-3dzVd8">
<div class="containerCozy-336-Cz container-206Blv">
<div class="markup-2BOw-j" style="text-align: center;">
<p><span style="font-size: small;"><img src="https://cdn.discordapp.com/attachments/617436511192743937/617437563019460618/logo_back.png" alt="" width="320" height="198" /></span></p>
<p><span style="font-size: medium;"><strong>Caminho Sem Volta / Quest</strong></span></p>
<p><span style="font-size: small;">Em todo o nosso territ&oacute;rio shinobi, &eacute; encontrado locais perigosos, com criaturas e ninjas sedentos por sangue, geralmente, caminhos que n&atilde;o oferecem nenhuma outra alternativa a n&atilde;o ser, seguir em frente.</span></p>
<p><span style="font-size: small;">&nbsp;</span></p>
<p><span style="font-size: small;"><strong>Por que ser&aacute; que caminhos como estes s&atilde;o t&atilde;o bem protegidos ?</strong></span></p>
<p><span style="font-size: small;"><strong><img src="https://media.discordapp.net/attachments/617877383533297687/617882327581851649/camu.png" alt="" width="602" height="210" /></strong></span></p>
<p><span style="font-size: small;"><strong>Voc&ecirc; n&atilde;o pode desistir, realize o trajeto por completo ou morra.</strong></span></p>
<p><span style="font-size: small;"><strong><img src="https://media.discordapp.net/attachments/617877383533297687/617882449589960729/cacammm.png" alt="" width="613" height="238" /></strong></span></p>
<p><span style="font-size: small;"><strong>N&atilde;o &eacute; atoa que s&atilde;o caminhos t&atilde;o bem protegidos, h&aacute; tesouros nestes locais, oque est&aacute; esperando para procur&aacute;-los ?</strong></span></p>
</div>
</div>
</div>
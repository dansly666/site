<p><img style="display: block; margin-left: auto; margin-right: auto;" src="https://cdn.discordapp.com/attachments/617436511192743937/617437563019460618/logo_back.png" alt="" width="307" height="190" /></p>
<p>&nbsp;</p>
<p style="text-align: center;"><span style="font-size: medium;"><strong>Gadua&ccedil;&otilde;es - Cl&aacute;ssifica&ccedil;&otilde;es da Academia Ninja</strong></span></p>
<p style="text-align: center;"><span style="font-size: small;">Uma forma de classificar Shinobi's qualificados para determinados territ&oacute;rios ou at&eacute; mesmo para realizar miss&otilde;es especiais !</span></p>
<p style="text-align: center;"><span style="font-size: small;">&nbsp;</span></p>
<p style="text-align: center;"><span style="font-size: medium;"><strong>&nbsp;N&iacute;veis de Gradua&ccedil;&atilde;o</strong></span></p>
<address style="text-align: center;"><span style="font-size: small;"><strong>Genin :&nbsp;</strong>Requer 20 Pontos de Gradua&ccedil;&atilde;o.</span></address><address style="text-align: center;"><span style="font-size: small;"><strong>Chunin :&nbsp;</strong>Requer 40 Pontos de&nbsp;Gradua&ccedil;&atilde;o.</span></address><address style="text-align: center;"><span style="font-size: small;"><strong>Jounin&nbsp;</strong>:&nbsp;Requer 60 Pontos de&nbsp;Gradua&ccedil;&atilde;o.</span></address><address style="text-align: center;"><span style="font-size: small;"><strong>Kage :&nbsp;</strong>Requer 100 Pontos de&nbsp;Gradua&ccedil;&atilde;o.</span></address>
<p style="text-align: center;"><span style="font-size: small;">&nbsp;</span></p>
<p style="text-align: center;"><span style="font-size: medium;"><strong>Pontos de Gradua&ccedil;&atilde;o</strong></span></p>
<p style="text-align: center;"><span style="font-size: small;">S&atilde;o recompensas por realizar objetivos pr&eacute; estabelicido in game como, Miss&otilde;es, Quests, Batalhas Di&aacute;rias dentre outros.</span></p>
<p style="text-align: center;"><span style="font-size: small;">&nbsp;</span></p>
<p style="text-align: center;"><span style="font-size: medium;"><strong>Recompensas de cada N&iacute;vel de Gradua&ccedil;&atilde;o&nbsp;</strong></span></p>
<address style="text-align: center;"><span style="font-size: small;"><strong>Genin</strong>&nbsp;: Presente + 1000 Pontos de Vida</span></address><address style="text-align: center;"><span style="font-size: small;"><strong>Chunin</strong>&nbsp;: Presente + 2000 Pontos de Vida</span></address><address style="text-align: center;"><span style="font-size: small;"><strong>Jounin</strong>&nbsp;: Presente + 3000 Pontos de Vida</span></address><address style="text-align: center;"><span style="font-size: small;"><strong>Kage</strong>&nbsp;: Presente + 4000 Pontos de vida</span></address>
<p style="text-align: center;"><span style="font-size: small;">&nbsp;</span></p>
<p style="text-align: center;"><span style="font-size: medium;"><strong>Como pegar a recompensa ?</strong></span></p>
<p style="text-align: center;"><span style="font-size: small;">Clique no certificado correspondente a sua gradua&ccedil;&atilde;o que est&aacute; em cima da mesa do Naruto!</span></p>
<p style="text-align: center;"><span style="font-size: small;"><img src="https://media.discordapp.net/attachments/617435915245322260/617873468674801701/gradcertifi.jpg" alt="" width="569" height="237" /></span></p>
<p style="text-align: center;"><span style="font-size: small;">&nbsp;</span></p>
<p style="text-align: center;"><span style="font-size: small;">Ap&oacute;s, leve o certificado at&eacute; Iruka Sensei e entregue-os.</span></p>
<p style="text-align: center;"><span style="font-size: small;"><img src="https://media.discordapp.net/attachments/617435915245322260/617873577923969045/certific2.jpg" alt="" width="556" height="218" /></span></p>
<p style="text-align: center;"><span style="font-size: small;"><strong>O que ser&aacute; que tem dentro desses presentes, em ?</strong></span></p>
<p style="text-align: center;"><span style="font-size: small;">Voc&ecirc; pode verificar quantos Pontos de Gradua&ccedil;&atilde;o possui com o comando !pontos</span></p>
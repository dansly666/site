<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
<ul>
<li><span style="font-size: small;">OBS : Donates atrav&eacute;s do PayPal n&atilde;o s&atilde;o autom&aacute;ticos, devem ser confirmados atrav&eacute;s do atendimento online do WhatsApp&nbsp;(67 ) 99855-2128.</span></li>
</ul>
<p>&nbsp;</p>
<p style="text-align: center;"><span style="font-size: small;"><input title="PayPal - The safer, easier way to pay online!" type="image" name="submit" src="https://www.paypalobjects.com/pt_BR/BR/i/btn/btn_donateCC_LG.gif" alt="Fa&ccedil;a doa&ccedil;&otilde;es com o bot&atilde;o do PayPal" /> <img style="display: block; margin-left: auto; margin-right: auto;" src="https://www.paypal.com/pt_BR/i/scr/pixel.gif" alt="" width="1" height="1" border="0" /></span></p>
</form>
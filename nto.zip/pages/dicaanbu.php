<p style="text-align: center;"><img src="https://cdn.discordapp.com/attachments/617436511192743937/617437563019460618/logo_back.png" alt="" width="317" height="196" /></p>
<p style="text-align: center;"><span style="font-size: medium;"><strong>&nbsp;Anbu / Akatsuki</strong></span></p>
<p style="text-align: center;"><span style="font-size: small;">A Anbu e Akatsuki est&atilde;o recrutando novos membros para suas organiza&ccedil;&otilde;es, qualquer shinobi que demonstrar aptid&atilde;o poder&aacute; ingressar em uma das duas.</span></p>
<p style="text-align: center;"><span style="font-size: small;">&nbsp;</span></p>
<p style="text-align: center;"><span style="font-size: medium;"><strong>Requerimento</strong></span></p>
<address style="text-align: center;"><span style="font-size: small;">Gradua&ccedil;&atilde;o : Chunin</span></address><address style="text-align: center;"><span style="font-size: small;">Level : 60</span></address>
<p style="text-align: center;"><span style="font-size: small;">&nbsp;</span></p>
<p style="text-align: center;"><span style="font-size: medium;"><strong>Recompensas</strong></span></p>
<address style="text-align: center;"><span style="font-size: small;">+ 3 Mil Pontos de Vida.</span></address><address style="text-align: center;"><span style="font-size: small;">+ 10 % Dano em Jutsus de ataque.</span></address><address style="text-align: center;"><span style="font-size: small;">+ Skin Mode Anbu/Akatsuki</span></address>
<p style="text-align: center;"><span style="font-size: small;">&nbsp;</span></p>
<p style="text-align: center;"><span style="font-size: medium;"><strong>Dicas</strong></span></p>
<p style="text-align: center;"><span style="font-size: small;"><strong>O Primeiro passo em ambas as organiza&ccedil;&otilde;es &eacute; realizar a miss&atilde;o do NPC Defender.</strong></span></p>
<p style="text-align: center;"><span style="font-size: small;"><img src="https://media.discordapp.net/attachments/617433870647689220/617862605180239924/org1.png" alt="" /></span></p>
<p style="text-align: center;"><span style="font-size: small;"><strong>O Segundo passo &eacute; derrotar todas as Bijus Confinadas.</strong></span></p>
<p style="text-align: center;"><span style="font-size: small;"><img src="https://media.discordapp.net/attachments/617433870647689220/617862708666171412/org2.png" alt="" /></span></p>
<p style="text-align: center;"><span style="font-size: small;"><strong>O Terceiro passo &eacute; realizar a miss&atilde;o do NPC [L&iacute;der] Tobi se for Akatsuki e Danzo se for Anbu.</strong></span></p>
<p style="text-align: center;"><span style="font-size: small;"><img src="https://media.discordapp.net/attachments/617433870647689220/617862926174257162/org3.png" alt="" /></span></p>
<p style="text-align: center;"><span style="font-size: small;"><strong>OBS : As imagens s&atilde;o referente a Base Akatsuki, porem os mesmos passos podem ser dados na Base Anbu.</strong></span></p>
<p style="text-align: center;"><span style="font-size: small;">&nbsp;</span></p>
<p style="text-align: center;"><span style="font-size: medium;"><img class="emoji" src="https://discordapp.com/assets/26a727a30b2342317fb0df394e399df1.svg" alt=":red_circle:" width="23" height="23" /><img class="emoji" src="https://discordapp.com/assets/26a727a30b2342317fb0df394e399df1.svg" alt=":red_circle:" width="23" height="23" /><strong>SPOILER</strong><img class="emoji" src="https://discordapp.com/assets/26a727a30b2342317fb0df394e399df1.svg" alt=":red_circle:" width="23" height="23" /><img class="emoji" src="https://discordapp.com/assets/26a727a30b2342317fb0df394e399df1.svg" alt=":red_circle:" width="23" height="23" /></span></p>
<p style="text-align: center;"><span style="font-size: small;">Antes de tudo, voc&ecirc; ter&aacute; que encontrar a Base Anbu e Akatsuki.&nbsp;</span></p>
<p style="text-align: center;"><span style="font-size: small;">A base Anbu &eacute; localizada abaixo da Arena PVP de Konoha, j&aacute; a base Akatsuki &eacute; encontrada nas media&ccedil;&otilde;es entre Konoha e Getsugakure.&nbsp;</span></p>
<p style="text-align: center;"><span style="font-size: small;">No primeiro passo voc&ecirc; ter&aacute; que derrotar Membros da Akatsuki ou Anbu para coletar os items necess&aacute;rios para a miss&atilde;o do NPC Defender.&nbsp;</span></p>
<p style="text-align: center;"><span style="font-size: small;">No segundo passo voc&ecirc; ter&aacute; que derrotar cada uma das 7 Bijus Confinadas que podem ser encontradas em ambas as bases.&nbsp;</span></p>
<p style="text-align: center;"><span style="font-size: small;">No terceiro passo voc&ecirc; ter&aacute; que invadir a base inimiga para coletar os items necess&aacute;rios para a miss&atilde;o do L&iacute;der da org que deseja se aliar.</span></p>
<p style="text-align: center;">&nbsp;</p>
<p style="text-align: center;">&nbsp;</p>
<p style="text-align: center;"><img src="https://cdn.discordapp.com/attachments/617436511192743937/617437563019460618/logo_back.png" alt="" width="339" height="210" /></p>
<p style="text-align: center;">&nbsp;</p>
<p style="text-align: center;"><span style="font-size: medium;"><strong>Upe Seu Personagem !</strong></span></p>
<p style="text-align: center;"><br /><span style="font-size: small;">Veja as principais formas de se adquirir experi&ecirc;ncia/level.</span></p>
<p style="text-align: center;">&nbsp;</p>
<p style="text-align: center;"><span style="font-size: medium;"><strong>Realizando Miss&otilde;es&nbsp;</strong></span></p>
<p style="text-align: center;"><span style="font-size: small;">Voc&ecirc; pode adquirir Exper&ecirc;ncia ao realizar qualquer Miss&otilde;es !</span></p>
<p style="text-align: center;"><img src="https://cdn.discordapp.com/attachments/617434728659812470/617439064513314817/npc.png" alt="" width="581" height="186" /></p>
<p style="text-align: center;">&nbsp;</p>
<p style="text-align: center;"><span style="font-size: medium;"><strong>Derrotando Criaturas</strong></span></p>
<p style="text-align: center;"><span style="font-size: small;">Fa&ccedil;a Hunts, ou derrote Boss's encontrados em todo o territ&oacute;rio Shinobi.</span></p>
<p style="text-align: center;"><img src="https://media.discordapp.net/attachments/617434728659812470/617439179605016622/hunt.png" alt="" width="586" height="183" /></p>
<p style="text-align: center;"><span style="font-size: medium;"><strong>Mestre de Batalhas&nbsp;</strong></span></p>
<p style="text-align: center;"><span style="font-size: small;">Um desaf&iacute;o ( Di&aacute;rio ), ao derrotar todos os 12 oponentes al&eacute;m de experi&ecirc;ncia ganhe tamb&eacute;m:</span></p>
<p style="text-align: center;"><span style="font-size: small;">( Pontos de Gradua&ccedil;&atilde;o ! )</span></p>
<p style="text-align: center;">&nbsp;</p>
<p style="text-align: center;"><img src="https://media.discordapp.net/attachments/617434728659812470/617439268935172147/batalhas.png" alt="" width="592" height="173" /></p>
<p style="text-align: center;"><span style="font-size: medium;"><strong>Explorando Kekkei Generators</strong></span></p>
<p style="text-align: center;"><span style="font-size: small;">Em todo o territ&oacute;rio Shinobi pode ser encontrado, Kekkei Generators, ao extra&iacute;-lo adquiri-se Experi&ecirc;ncia. Cada Kekkei Generator leva 24 Horas para poder ser extra&iacute;do novamente.</span></p>
<p style="text-align: center;">&nbsp;</p>
<p style="text-align: center;"><img src="https://media.discordapp.net/attachments/617434728659812470/617439397805031464/explorat.png" alt="" width="594" height="179" /></p>
<p style="text-align: center;"><span style="font-size: medium;"><strong>Participa&ccedil;&otilde;es em PVP</strong></span></p>
<p style="text-align: center;"><span style="font-size: small;">Ao derrotar qualquer outro jogador de Level superior ou igual ao seu, adquire-se Experi&ecirc;ncia.</span></p>
<p><span><img style="display: block; margin-left: auto; margin-right: auto;" src="https://media.discordapp.net/attachments/617434728659812470/617439532593446912/PK.png" alt="" width="596" height="217" /></span></p>
<p>&nbsp;</p>
<p>&nbsp;</p>
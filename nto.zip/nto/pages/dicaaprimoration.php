<div class="contentCozy-3XX413 content-3dzVd8">
<div class="containerCozy-336-Cz container-206Blv">
<div class="markup-2BOw-j" style="text-align: center;"><span style="font-size: small;"><img src="https://i.ibb.co/cD6d7FR/logo-back.png" alt="" width="331" height="205" /></span></div>
</div>
</div>
<div>
<div class="contentCozy-3XX413 content-3dzVd8">
<div class="containerCozy-336-Cz container-206Blv" style="text-align: center;">
<div class="contentCozy-3XX413 content-3dzVd8">
<div class="containerCozy-336-Cz container-206Blv">
<div class="markup-2BOw-j"><span style="font-size: small;">&nbsp;</span></div>
<div class="markup-2BOw-j"><span style="font-size: medium;"><strong>Kit's de Aprimoramento e Encantamentos &nbsp;</strong></span></div>
<div class="markup-2BOw-j"><span style="font-size: small;">&nbsp;</span></div>
<div class="markup-2BOw-j"><span style="font-size: small;"><img src="https://media.discordapp.net/attachments/629011851321016350/630501969852629023/refinos.png" alt="" />&nbsp;</span></div>
<div class="markup-2BOw-j"><span style="font-size: small;"><img class="emoji" src="https://discordapp.com/assets/df0fba917be2ad5fc7939019465de627.svg" alt=":round_pushpin:" width="15" height="15" />&nbsp;Em Konoha voc&ecirc; pode encontrar por Hishura um NPC Especialista em forjar items que visam aprimorar seu personagem e seus equipamentos</span></div>
<div class="markup-2BOw-j"><span style="font-size: small;">&nbsp;</span></div>
</div>
<div class="containerCozy-B4noqO container-1e22Ot"><span style="font-size: small;" data-mce-mark="1">&nbsp;</span></div>
</div>
<address class="markup-2BOw-j">&nbsp;</address>
<div>
<div class="contentCozy-3XX413 content-3dzVd8">
<div class="containerCozy-B4noqO container-1e22Ot"><span style="font-size: small;" data-mce-mark="1"><a class="anchor-3Z-8Bb anchorUnderlineOnHover-2ESHQB imageWrapper-2p5ogY imageZoom-1n-ADA clickable-3Ya1ho embedWrapper-3AbfJJ" href="https://cdn.discordapp.com/attachments/629011851321016350/630505973076721714/Adamantium_45817.png" rel="noreferrer noopener" target="_blank"><img src="https://media.discordapp.net/attachments/629011851321016350/630505973076721714/Adamantium_45817.png" alt="" width="85" height="85" /></a></span></div>
</div>
</div>
<div>
<div class="contentCozy-3XX413 content-3dzVd8">
<div class="containerCozy-336-Cz container-206Blv"><address class="markup-2BOw-j"><span style="font-size: small;" data-mce-mark="1"><strong>Adamantium</strong>&nbsp;: Adamantium &eacute; o principal material utilizado por Hishura, &eacute; com ele que voc&ecirc; conseguir&aacute; forjar seus kit's.<img class="emoji" src="https://discordapp.com/assets/c6b26ba81f44b0c43697852e1e1d1420.svg" alt=":white_check_mark:" width="12" height="12" /><br /></span></address></div>
<address class="containerCozy-B4noqO container-1e22Ot"><span style="font-size: small;" data-mce-mark="1">&nbsp;</span></address></div>
</div>
<address class="markup-2BOw-j">&nbsp;</address>
<div>
<div class="contentCozy-3XX413 content-3dzVd8">
<div class="containerCozy-336-Cz container-206Blv"><span style="font-size: small;" data-mce-mark="1">&nbsp;</span></div>
<div class="containerCozy-B4noqO container-1e22Ot"><span style="font-size: small;" data-mce-mark="1"><a class="anchor-3Z-8Bb anchorUnderlineOnHover-2ESHQB imageWrapper-2p5ogY imageZoom-1n-ADA clickable-3Ya1ho embedWrapper-3AbfJJ" href="https://cdn.discordapp.com/attachments/629011851321016350/630506041880084485/aprimora_33388.png" rel="noreferrer noopener" target="_blank"><img src="https://media.discordapp.net/attachments/629011851321016350/630506041880084485/aprimora_33388.png" alt="" width="78" height="78" /></a></span></div>
</div>
</div>
<address class="markup-2BOw-j">&nbsp;</address>
<div>
<div class="contentCozy-3XX413 content-3dzVd8"><address class="containerCozy-336-Cz container-206Blv"><span style="font-size: small;" data-mce-mark="1"><strong><span data-mce-mark="1">&nbsp;</span></strong><span data-mce-mark="1"><strong>Kit of Aprimoration</strong>&nbsp;: Com este Kit voc&ecirc; poder&aacute; elevar o n&iacute;vel de aprimoramento do seu equipamento at&eacute; o Nivel + 10, cada n&iacute;vel oferece um b&ocirc;nus de :</span></span></address></div>
</div>
<address class="markup-2BOw-j">&nbsp;</address>
<div class="contentCozy-3XX413 content-3dzVd8">
<div class="containerCozy-336-Cz container-206Blv"><address class="buttonContainer-KtQ8wc"><span style="font-size: small;" data-mce-mark="1">&nbsp;</span></address><address class="markup-2BOw-j"><span style="font-size: small;" data-mce-mark="1"><strong>5</strong>&nbsp;de Def em Escudos &nbsp;</span></address><address class="markup-2BOw-j"><span style="font-size: small;" data-mce-mark="1"><strong>25</strong>&nbsp;de Atk em Armas &nbsp;</span></address><address class="markup-2BOw-j"><span style="font-size: small;" data-mce-mark="1"><strong>2</strong>&nbsp;de Arm em Set's.<img class="emoji" src="https://discordapp.com/assets/c6b26ba81f44b0c43697852e1e1d1420.svg" alt=":white_check_mark:" width="12" height="12" /></span></address>
<div class="markup-2BOw-j">&nbsp;</div>
</div>
</div>
<address class="markup-2BOw-j">&nbsp;</address>
<div>
<div class="contentCozy-3XX413 content-3dzVd8"><address class="containerCozy-336-Cz container-206Blv"><span style="font-size: small;" data-mce-mark="1">&nbsp;</span></address>
<div class="containerCozy-B4noqO container-1e22Ot"><span style="font-size: small;" data-mce-mark="1"><a class="anchor-3Z-8Bb anchorUnderlineOnHover-2ESHQB imageWrapper-2p5ogY imageZoom-1n-ADA clickable-3Ya1ho embedWrapper-3AbfJJ" href="https://cdn.discordapp.com/attachments/629011851321016350/630506255361769480/critical_33378.png" rel="noreferrer noopener" target="_blank"><img src="https://media.discordapp.net/attachments/629011851321016350/630506255361769480/critical_33378.png" alt="" width="72" height="72" /></a></span></div>
</div>
</div>
<div>
<div class="contentCozy-3XX413 content-3dzVd8">
<div class="containerCozy-336-Cz container-206Blv"><address class="markup-2BOw-j"><span style="font-size: small;" data-mce-mark="1"><strong>Kit of Critical Power</strong>&nbsp;: Com este Kit voc&ecirc; poder&aacute; elevar o n&iacute;vel de Cr&iacute;tico do seu Personagem at&eacute; + 10, quanto mais elevado for seu n&iacute;vel maior ser&aacute; a chance de efetuar um dano Cr&iacute;tico.<img class="emoji" src="https://discordapp.com/assets/c6b26ba81f44b0c43697852e1e1d1420.svg" alt=":white_check_mark:" width="12" height="12" /></span></address></div>
<address class="containerCozy-B4noqO container-1e22Ot"><span style="font-size: small;" data-mce-mark="1">&nbsp;</span></address></div>
</div>
<div>
<div class="contentCozy-3XX413 content-3dzVd8">
<div class="containerCozy-B4noqO container-1e22Ot"><span style="font-size: small;">&nbsp;</span></div>
</div>
</div>
<address class="markup-2BOw-j">&nbsp;</address>
<div>
<div class="contentCozy-3XX413 content-3dzVd8">
<div class="containerCozy-336-Cz container-206Blv"><address class="buttonContainer-KtQ8wc"><span style="font-size: small;"><span data-mce-mark="1">&nbsp;</span><img src="https://media.discordapp.net/attachments/629011851321016350/635950300179595289/12580.png" alt="" width="74" height="74" /></span></address><address class="markup-2BOw-j"><span style="font-size: small;" data-mce-mark="1"><strong>Senju / Sannin Enchanted</strong>&nbsp;:Com este item voc&ecirc; poder&aacute; encantar seu Senju Set N&iacute;vel 7 ou Kurama Set N&iacute;vel 7 para a vers&atilde;o Ultimate N&iacute;vel 8.<img class="emoji" src="https://discordapp.com/assets/c6b26ba81f44b0c43697852e1e1d1420.svg" alt=":white_check_mark:" width="12" height="12" /></span></address></div>
</div>
</div>
<address class="markup-2BOw-j"><span style="font-size: small;" data-mce-mark="1">&nbsp;</span></address></div>
</div>
</div>
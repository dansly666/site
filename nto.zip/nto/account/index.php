<?php
header ("location: ../");
?>